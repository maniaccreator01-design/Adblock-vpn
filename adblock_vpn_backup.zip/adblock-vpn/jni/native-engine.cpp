#include <jni.h>
#include <unistd.h>
#include <sys/types.h>
#include <vector>
#include <string>
#include <unordered_set>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <arpa/inet.h>
#include <android/log.h>

#define LOG_TAG "AdBlockEngine"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Global blocklist set for O(1) ultra-fast lookups
std::unordered_set<std::string> ad_blocklist;

// Populate our blocklist with test domains
void initializeBlocklist() {
    ad_blocklist.insert("ads.doubleclick.net");
    ad_blocklist.insert("analytics.google.com");
    ad_blocklist.insert("graph.facebook.com");
    ad_blocklist.insert("test-ad-domain.com");
    LOGI("Blocklist initialized with sample domains.");
}

// Dummy function for now to handle blocking
void forgeDnsNxdomainResponse(int tun_fd) {
    LOGI("Sinking ad domain: Sending NXDOMAIN response.");
    // Real byte-swapping logic goes here later
}

// Parses the raw DNS payload labels into a standard string
void handleDnsQuery(uint8_t* dns_payload, size_t payload_len, int tun_fd) {
    if (payload_len < 12) return; // DNS header minimum size

    size_t pos = 12; // Skip 12-byte DNS fixed header
    std::string domain = "";

    // Parse DNS length-prefixed labels
    while (pos < payload_len) {
        uint8_t label_len = dns_payload[pos];
        if (label_len == 0) break; // End of domain name

        pos++; // Move past length byte

        if (!domain.empty()) {
            domain += ".";
        }
        
        for (uint8_t i = 0; i < label_len && pos < payload_len; i++) {
            domain += (char)dns_payload[pos];
            pos++;
        }
    }

    // Check parsed domain against blocklist
    if (ad_blocklist.find(domain) != ad_blocklist.end()) {
        LOGI("[BLOCKED] Caught ad domain: %s", domain.c_str());
        forgeDnsNxdomainResponse(tun_fd);
    } else {
        LOGI("[ALLOWED] Passing safe domain: %s", domain.c_str());
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_adblockvpn_MyVpnService_startNativeEngine(JNIEnv *env, jobject thiz, jint tun_fd) {
    
    std::vector<uint8_t> buffer(16384); 
    
    // Seed the list once before entering the packet loop
    initializeBlocklist();

    LOGI("C++ Engine active. Listening on TUN FD: %d", tun_fd);

    while (true) {
        ssize_t length = read(tun_fd, buffer.data(), buffer.size());
        
        if (length < 0) {
            LOGE("Critical: Read failed. Exiting loop.");
            break;
        }

        if (length > 0) {
            uint8_t* packet = buffer.data();
            struct iphdr* ip_header = (struct iphdr*)packet;
            
            if (ip_header->version == 4) { // Process IPv4 traffic
                size_t ip_header_len = ip_header->ihl * 4;

                if (ip_header->protocol == IPPROTO_UDP) {
                    struct udphdr* udp_header = (struct udphdr*)(packet + ip_header_len);

                    if (ntohs(udp_header->dest) == 53) { // Is destination Port 53?
                        uint8_t* dns_payload = (packet + ip_header_len + 8);
                        size_t udp_len = ntohs(udp_header->len);
                        size_t dns_payload_len = udp_len - 8;

                        handleDnsQuery(dns_payload, dns_payload_len, tun_fd);
                    }
                }
            }
        }
    }
}
