package com.example.adblockvpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class MainActivity : Activity() {

    private var isVpnRunning = false
    private val VPN_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnToggle = findViewById<Button>(R.id.btnToggleVpn)

        btnToggle.setOnClickListener {
            if (isVpnRunning) {
                stopVpnService()
                btnToggle.text = "Start VPN AdBlocker"
                isVpnRunning = false
            } else {
                startVpnWithPermissionCheck()
            }
        }
    }

    private fun startVpnWithPermissionCheck() {
        // Check if the Android system has already authorized this app's VPN profile
        val intent = VpnService.prepare(this)
        if (intent != null) {
            // Trigger the native Android system dialog permission box
            startActivityForResult(intent, VPN_REQUEST_CODE)
        } else {
            // Already permitted, launch the engine directly
            onActivityResult(VPN_REQUEST_CODE, RESULT_OK, null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQUEST_CODE && resultCode == RESULT_OK) {
            startService(Intent(this, MyVpnService::class.java))
            findViewById<Button>(R.id.btnToggleVpn).text = "Stop VPN AdBlocker"
            isVpnRunning = true
            Toast.makeText(this, "AdBlocker Active!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopVpnService() {
        stopService(Intent(this, MyVpnService::class.java))
        Toast.makeText(this, "AdBlocker Deactivated", Toast.LENGTH_SHORT).show()
    }
}
