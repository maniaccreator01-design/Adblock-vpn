package com.example.adblockvpn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.IOException

class MyVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var vpnThread: Thread? = null

    companion object {
        private const val TAG = "AdBlockVpnService"

        init {
            System.loadLibrary("native-engine")
        }
    }

    private external fun startNativeEngine(tunFd: Int)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.i(TAG, "VPN Service Starting...")
        stopVpn()

        try {
            val builder = Builder()
                .setMtu(1500)
                .addAddress("10.0.0.1", 32)
                .addRoute("0.0.0.0", 0)    
                .addDnsServer("10.0.0.1")  
                .setSession("AdBlockLocalVPN")

            vpnInterface = builder.establish()
            val tunFd = vpnInterface!!.fd

            vpnThread = Thread {
                startNativeEngine(tunFd)
            }.apply {
                start()
            }

        } catch (e: Exception) {
            Log.e(TAG, "Failed to establish VPN interface", e)
        }

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        stopVpn()
    }

    private fun stopVpn() {
        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (e: IOException) {
            Log.e(TAG, "Error closing VPN interface", e)
        }
        vpnThread?.interrupt()
        vpnThread = null
    }
}
