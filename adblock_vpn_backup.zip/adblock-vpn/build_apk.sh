# Define paths clearly
ANDROID_JAR="/opt/android-sdk/platforms/android-34/android.jar"
AAPT_TOOL="/usr/bin/aapt"

echo "=== Step 3: Packaging Resources ==="
# Run the package tool with the platform library linked via the -I flag
$AAPT_TOOL package -f -m -J build/gen -S res -M AndroidManifest.xml -I "$ANDROID_JAR" -F build/resources.ap_


set -e

echo "=== Step 1: Initializing build folders ==="
mkdir -p build/gen/com/example/adblockvpn build/obj build/apk/lib/arm64-v8a build/apk/res/layout platforms

echo "=== Step 2: Compiling C++ VPN Engine ==="
mkdir -p build/apk/lib/arm64-v8a
cd build
cmake ../jni
make
# Move the compiled library into the APK folder
if [ -f "libnative-engine.so" ]; then
    cp libnative-engine.so apk/lib/arm64-v8a/
else
    echo "ERROR: Compilation finished but libnative-engine.so was not created."
    exit 1
fi
cd ..


echo "=== Step 3: Fetching Android Framework ==="
# Download a guaranteed working API 34 platform dictionary directly
if [ ! -f "platforms/android.jar" ]; then
    pkg install -y wget
    wget "https://raw.githubusercontent.com/Skatty/android.jar/master/android-34/android.jar" -O platforms/android.jar
fi

ANDROID_JAR="$HOME/adblock-vpn/platforms/android.jar"

echo "=== Step 4: Packaging layout resources ==="
# Ensure this path matches your installed platform version
ANDROID_JAR="/opt/android-sdk/platforms/android-34/android.jar"

echo "=== Packaging Resources ==="
/usr/bin/aapt package -f -m -J build/gen -S res -M AndroidManifest.xml -I "$ANDROID_JAR" -F build/resources.ap_



echo "=== Step 5: Compiling Kotlin source ==="
pkg install -y kotlinc
kotlinc kotlin/*.kt build/gen/com/example/adblockvpn/*.java -cp "$ANDROID_JAR" -d build/obj

echo "=== Step 6: Converting bytecode to Dex ==="
dx --dex --output=build/apk/classes.dex build/obj

echo "=== Step 7: Assembling APK components ==="
cp build/resources.ap_ build/adblock-unsigned.apk
cd build/apk
zip -r9 ../adblock-unsigned.apk classes.dex lib
cd ../..

echo "=== Step 8: Signing the binary package ==="
if [ ! -f my-key.keystore ]; then
    keytool -genkeypair -v -keystore my-key.keystore -alias adblock -keyalg RSA -keysize 2048 -validity 10000 -storepass password -keypass password -dname "CN=Local, O=Dev, C=US"
fi

apksigner sign --ks my-key.keystore --ks-pass pass:password --out adblock-vpn.apk build/adblock-unsigned.apk

echo "=========================================="
echo " SUCCESS! Built: adblock-vpn.apk"
echo "=========================================="
